Sample: deviceQuery
Minimum spec: SM 2.0

This sample enumerates the properties of the CUDA devices present in the system.

Key concepts:
CUDA Runtime API
Device Query
