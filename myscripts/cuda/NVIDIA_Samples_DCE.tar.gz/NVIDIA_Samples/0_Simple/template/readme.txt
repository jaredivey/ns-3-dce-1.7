Sample: template
Minimum spec: SM 2.0

A trivial template project that can be used as a starting point to create new CUDA projects.

Key concepts:
Device Memory Allocation
