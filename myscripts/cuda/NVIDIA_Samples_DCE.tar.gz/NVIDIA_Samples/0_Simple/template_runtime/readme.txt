Sample: template_runtime
Minimum spec: SM 2.0

A trivial template project that can be used as a starting point to create new CUDA Runtime API projects.

Key concepts:
CUDA Data Transfers
Device Memory Allocation
