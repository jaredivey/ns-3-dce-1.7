Sample: simpleTexture
Minimum spec: SM 2.0

Simple example that demonstrates use of Textures in CUDA.

Key concepts:
CUDA Runtime API
Texture
Image Processing
