///This file contains functions from Brian Conte's crypto-algorithms project, at github.com/B-Con/crypto-algorithms
///These functions are preceded by the appropriate attribution
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <cuda.h>
#include <cudaProfiler.h>
#include <builtin_types.h>
#include <drvapi_error_string.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/sendfile.h>
#include <fcntl.h>
#include <netdb.h>
#include <errno.h>
#include <string>

#include <helper_cuda_drvapi.h>
#include <helper_timer.h>
#include <helper_string.h>
#include <helper_image.h>

#include "aes_dce.h"

CUdevice cuDevice;
CUcontext cuContext;
CUmodule cuModule;

//#define BLOCKS_PER_LAUNCH 5
//#define THREADS_PER_BLOCK 512
//#define AES_BLOCK_SIZE 16               // AES operates on 16 bytes at a time

//define input ptx file for different platforms
#if defined(_WIN64) || defined(__LP64__)
#define PTX_FILE "aes_kernel64.ptx"
#define CUBIN_FILE "aes_kernel64.cubin"
#else
#define PTX_FILE "aes_kernel32.ptx"
#define CUBIN_FILE "aes_kernel32.cubin"
#endif

static CUfunction cuda_aes_encrypt_ctr = NULL;
static CUfunction cuda_aes_encrypt = NULL;
static CUfunction cuda_aes_decrypt = NULL;

//Useful macros
//#define MAX(X,Y) ((X) > (Y) ? (X) : (Y))
#define KE_ROTWORD(x) (((x) << 8) | ((x) >> 24))

#define ALIGN_UP(offset, alignment) \
	(offset) = ((offset) + (alignment) - 1) & ~((alignment) - 1)

#define CORRECT_ARGC 4	//The number of command line arguments for all modes of operation

static CUresult
initCUDA(int argc, char **argv);

//Data type definitions
typedef enum 
{
	CTR,
	ECB_ENCRYPT,
	ECB_DECRYPT
} Operation;

typedef unsigned char BYTE;            // 8-bit byte
typedef unsigned int WORD;             // 32-bit word, change to "long" for 16-bit machines



//Host function declarations
void launchKernel(char *inFileName, char *outFileName, Operation operation);
void aes_key_setup(const BYTE key[], WORD w[], int keysize);
CUdeviceptr getKeySchedule(char *keyFilename, Operation operation);
void pad(char *chunk, int lastBlockSize);
WORD SubWord(WORD word);

/*
#define SBOX {\
	{0x63,0x7C,0x77,0x7B,0xF2,0x6B,0x6F,0xC5,0x30,0x01,0x67,0x2B,0xFE,0xD7,0xAB,0x76},\
	{0xCA,0x82,0xC9,0x7D,0xFA,0x59,0x47,0xF0,0xAD,0xD4,0xA2,0xAF,0x9C,0xA4,0x72,0xC0},\
	{0xB7,0xFD,0x93,0x26,0x36,0x3F,0xF7,0xCC,0x34,0xA5,0xE5,0xF1,0x71,0xD8,0x31,0x15},\
	{0x04,0xC7,0x23,0xC3,0x18,0x96,0x05,0x9A,0x07,0x12,0x80,0xE2,0xEB,0x27,0xB2,0x75},\
	{0x09,0x83,0x2C,0x1A,0x1B,0x6E,0x5A,0xA0,0x52,0x3B,0xD6,0xB3,0x29,0xE3,0x2F,0x84},\
	{0x53,0xD1,0x00,0xED,0x20,0xFC,0xB1,0x5B,0x6A,0xCB,0xBE,0x39,0x4A,0x4C,0x58,0xCF},\
	{0xD0,0xEF,0xAA,0xFB,0x43,0x4D,0x33,0x85,0x45,0xF9,0x02,0x7F,0x50,0x3C,0x9F,0xA8},\
	{0x51,0xA3,0x40,0x8F,0x92,0x9D,0x38,0xF5,0xBC,0xB6,0xDA,0x21,0x10,0xFF,0xF3,0xD2},\
	{0xCD,0x0C,0x13,0xEC,0x5F,0x97,0x44,0x17,0xC4,0xA7,0x7E,0x3D,0x64,0x5D,0x19,0x73},\
	{0x60,0x81,0x4F,0xDC,0x22,0x2A,0x90,0x88,0x46,0xEE,0xB8,0x14,0xDE,0x5E,0x0B,0xDB},\
	{0xE0,0x32,0x3A,0x0A,0x49,0x06,0x24,0x5C,0xC2,0xD3,0xAC,0x62,0x91,0x95,0xE4,0x79},\
	{0xE7,0xC8,0x37,0x6D,0x8D,0xD5,0x4E,0xA9,0x6C,0x56,0xF4,0xEA,0x65,0x7A,0xAE,0x08},\
	{0xBA,0x78,0x25,0x2E,0x1C,0xA6,0xB4,0xC6,0xE8,0xDD,0x74,0x1F,0x4B,0xBD,0x8B,0x8A},\
	{0x70,0x3E,0xB5,0x66,0x48,0x03,0xF6,0x0E,0x61,0x35,0x57,0xB9,0x86,0xC1,0x1D,0x9E},\
	{0xE1,0xF8,0x98,0x11,0x69,0xD9,0x8E,0x94,0x9B,0x1E,0x87,0xE9,0xCE,0x55,0x28,0xDF},\
	{0x8C,0xA1,0x89,0x0D,0xBF,0xE6,0x42,0x68,0x41,0x99,0x2D,0x0F,0xB0,0x54,0xBB,0x16}\
}

BYTE aes_sbox[16][16] = SBOX;
*/

// This function returns the best GPU based on performance
inline int getMaxGflopsDeviceId()
{
    CUdevice current_device = 0, max_perf_device = 0;
    int device_count     = 0, sm_per_multiproc = 0;
    int max_compute_perf = 0, best_SM_arch     = 0;
    int major = 0, minor = 0, multiProcessorCount, clockRate;

    cuInit(0);
    checkCudaErrors(cuDeviceGetCount(&device_count));

    // Find the best major SM Architecture GPU device
    while (current_device < device_count)
    {
        checkCudaErrors(cuDeviceComputeCapability(&major, &minor, current_device));

        if (major > 0 && major < 9999)
        {
            best_SM_arch = MAX(best_SM_arch, major);
        }

        current_device++;
    }

    // Find the best CUDA capable GPU device
    current_device = 0;

    while (current_device < device_count)
    {
        checkCudaErrors(cuDeviceGetAttribute(&multiProcessorCount,
                                             CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT,
                                             current_device));
        checkCudaErrors(cuDeviceGetAttribute(&clockRate,
                                             CU_DEVICE_ATTRIBUTE_CLOCK_RATE,
                                             current_device));
        checkCudaErrors(cuDeviceComputeCapability(&major, &minor, current_device));

        if (major == 9999 && minor == 9999)
        {
            sm_per_multiproc = 1;
        }
        else
        {
            sm_per_multiproc = 1;//_ConvertSMVer2Cores(major, minor);
        }

        int compute_perf  = multiProcessorCount * sm_per_multiproc * clockRate;

        if (compute_perf  > max_compute_perf)
        {
            // If we find GPU with SM major > 2, search only these
            if (best_SM_arch > 2)
            {
                // If our device==dest_SM_arch, choose this, or else pass
                if (major == best_SM_arch)
                {
                    max_compute_perf  = compute_perf;
                    max_perf_device   = current_device;
                }
            }
            else
            {
                max_compute_perf  = compute_perf;
                max_perf_device   = current_device;
            }
        }

        ++current_device;
    }

    return max_perf_device;
}

inline int cudaDeviceInit(int ARGC, char **ARGV)
{
    int cuDevice = 0;
    int deviceCount = 0;
    CUresult err = cuInit(0);

    if (CUDA_SUCCESS == err)
    {
        checkCudaErrors(cuDeviceGetCount(&deviceCount));
    }

    if (deviceCount == 0)
    {
        fprintf(stderr, "cudaDeviceInit error: no devices supporting CUDA\n");
        exit(EXIT_FAILURE);
    }

    int dev = 0;
    dev = getCmdLineArgumentInt(ARGC, (const char **) ARGV, "device=");

    if (dev < 0)
    {
        dev = 0;
    }

    if (dev > deviceCount-1)
    {
        fprintf(stderr, "\n");
        fprintf(stderr, ">> %d CUDA capable GPU device(s) detected. <<\n", deviceCount);
        fprintf(stderr, ">> cudaDeviceInit (-device=%d) is not a valid GPU device. <<\n", dev);
        fprintf(stderr, "\n");
        return -dev;
    }

    checkCudaErrors(cuDeviceGet(&cuDevice, dev));
    char name[100];
    cuDeviceGetName(name, 100, cuDevice);

    if (checkCmdLineFlag(ARGC, (const char **) ARGV, "quiet") == false)
    {
        printf("> Using CUDA Device [%d]: %s\n", dev, name);
    }

    return dev;
}

// General initialization call to pick the best CUDA Device
inline CUdevice findCudaDevice(int argc, char **argv, int *p_devID)
{
    CUdevice cuDevice;
    int devID = 0;

    // If the command-line has a device number specified, use it
    if (checkCmdLineFlag(argc, (const char **)argv, "device"))
    {
        devID = cudaDeviceInit(argc, argv);

        if (devID < 0)
        {
            printf("exiting...\n");
            exit(EXIT_SUCCESS);
        }
    }
    else
    {
        // Otherwise pick the device with highest Gflops/s
        char name[100];
        devID = getMaxGflopsDeviceId();
        checkCudaErrors(cuDeviceGet(&cuDevice, devID));
        cuDeviceGetName(name, 100, cuDevice);
        printf("> Using CUDA Device [%d]: %s\n", devID, name);
    }

    cuDeviceGet(&cuDevice, devID);

    if (p_devID)
    {
        *p_devID = devID;
    }

    return cuDevice;
}



int main(int argc, char **argv)
{
	//Parse command line arguments
	if(argc < CORRECT_ARGC)
	{
		printf("Insufficient parameters specified. The correct format is %s [ecb_encrypt|ecb_decrypt|ctr] [INPUT FILE] [KEY FILE]\n", argv[0]);
	}
	else
	{
		char *operation = argv[1];
		char *inputFilename = argv[2];
		char *keyFilename = argv[3];
                char *hostAddress = argv[4];
                char *device = (char*)"";
                int devNum = 0;
                if (argc == CORRECT_ARGC + 1)
                {
                    device = argv[5];
                    devNum = atoi(device);
                }

		printf("Operation: %s\n", operation);
                // initialize CUDA

                if (initCUDA(argc, argv) != CUDA_SUCCESS)
                {
			printf("Cuda init failed\n");
                        exit (1);
                }

		if(strcmp(operation, "ecb_encrypt") == 0)
		{
			printf("Launching kernel encrypt\n");
			launchKernel(inputFilename, keyFilename, ECB_ENCRYPT);
		}
		else if(strcmp(operation, "ecb_decrypt") == 0)
		{
			launchKernel(inputFilename, keyFilename, ECB_DECRYPT);
		}
		else if(strcmp(operation, "ctr") == 0)
		{
			launchKernel(inputFilename, keyFilename, CTR);
		}
		else
		{
			printf("Invalid operation specified. Valid choices are \"ecb_encrypt\", \"ecb_decrypt\", and \"ctr\".");
		}
	}
	
    return 0;
}

///Read input file, allocate device memory and invoke specified kernel, writing results to file
void launchKernel(char *inFilename, char *keyFilename, Operation operation)
{
	//Open the file for reading
	//Make output file name
	char *outFilename = (char *)malloc(strlen(inFilename) + 5);
	sprintf(outFilename, "%s.out", inFilename);

	FILE *fp_in = fopen(inFilename , "rb");
	
	FILE *fp_out = fopen(outFilename, "ab");
	char *h_chunkData;
	printf("Outfile: %s\n", outFilename);
	//Create the key schedule
	CUdeviceptr d_keySchedule_data = 0;
	if(d_keySchedule_data = getKeySchedule(keyFilename, operation))
	{
		//Each kernel launch can handle 512 threads each operating on AES_BLOCKSIZE bytes
		///So read the file in AES_BLOCKSIZE * THREADS_PER_BLOCK * BLOCKS_PER_LAUNCH chunks
		if(fp_in)
		{
			int chunkSize = AES_BLOCK_SIZE * THREADS_PER_BLOCK * BLOCKS_PER_LAUNCH;
			h_chunkData = (char *)malloc(chunkSize);
			//Read the file in 1 chunk at a time, until fread returns something other than the chunk size
			int lastChunkSize;
			int counter = 0;
			do
			{
				lastChunkSize = fread(h_chunkData, 1, chunkSize, fp_in);
				//Pad the last block if its size is not a multiple of the block size
				int lastBlockRemainder = lastChunkSize % AES_BLOCK_SIZE;
				if (lastBlockRemainder > 0)
				{
					pad(h_chunkData + lastChunkSize - lastBlockRemainder, lastBlockRemainder);
				}
				CUdeviceptr d_chunk;
				lastChunkSize += ((AES_BLOCK_SIZE - lastBlockRemainder) % AES_BLOCK_SIZE);
				
				checkCudaErrors(cuMemAlloc(&d_chunk, lastChunkSize));
				checkCudaErrors(cuMemcpyHtoD( d_chunk, h_chunkData, lastChunkSize));
//				gpuErrchk(cudaMemcpy(d_chunk, h_chunkData, lastChunkSize, cudaMemcpyHostToDevice));

				switch (operation)
				{
				case CTR:
				{
					int offset = 0;
					
					void* ptr = (void*)(size_t)d_chunk;
					cuParamSetv(cuda_aes_encrypt_ctr, offset, &ptr, sizeof(ptr));
					offset += sizeof(ptr);
					cuParamSetv(cuda_aes_encrypt_ctr, offset, &ptr, sizeof(ptr));
					offset += sizeof(ptr);
					cuParamSetv(cuda_aes_encrypt_ctr, offset, &d_keySchedule_data, sizeof(WORD));
					offset += sizeof(WORD);
					cuParamSeti(cuda_aes_encrypt_ctr, offset, chunkSize);
					offset += sizeof(chunkSize);
					cuParamSeti(cuda_aes_encrypt_ctr, offset, counter);
					offset += sizeof(counter);	

					cuParamSetSize(cuda_aes_encrypt_ctr, offset);
					cuFuncSetBlockShape(cuda_aes_encrypt_ctr, THREADS_PER_BLOCK, 1, 1);
					cuFuncSetSharedSize(cuda_aes_encrypt_ctr, 0);

				 	cuLaunchGrid(cuda_aes_encrypt_ctr, BLOCKS_PER_LAUNCH, 1);

					//cuda_aes_encrypt_ctr<<<BLOCKS_PER_LAUNCH, THREADS_PER_BLOCK>>>((BYTE *)d_chunk, (BYTE *)d_chunk, chunkSize, counter);
				}
				break;
				case ECB_ENCRYPT:
				{
					printf("ECB_ENCRYPT\n");
					int offset = 0;
					
					void* ptr = (void*)(size_t)d_chunk;
					void* ptr2 = (void*)(size_t)d_keySchedule_data;

					ALIGN_UP(offset, __alignof(ptr));
					cuParamSetv(cuda_aes_encrypt, offset, &ptr, sizeof(ptr));
					offset += sizeof(ptr);
					ALIGN_UP(offset, __alignof(ptr));
					cuParamSetv(cuda_aes_encrypt, offset, &ptr, sizeof(ptr));
					offset += sizeof(ptr);
					ALIGN_UP(offset, __alignof(ptr2));
					cuParamSetv(cuda_aes_encrypt, offset, &ptr2, sizeof(ptr2));
					offset += sizeof(ptr2);
					ALIGN_UP(offset, __alignof(chunkSize));
					cuParamSeti(cuda_aes_encrypt, offset, chunkSize);
					offset += sizeof(chunkSize);

					cuParamSetSize(cuda_aes_encrypt, offset);
					cuFuncSetBlockShape(cuda_aes_encrypt, THREADS_PER_BLOCK, 1, 1);
					cuFuncSetSharedSize(cuda_aes_encrypt, 0);

				 	cuLaunchGrid(cuda_aes_encrypt, BLOCKS_PER_LAUNCH, 1);


					//cuda_aes_encrypt<<<BLOCKS_PER_LAUNCH, THREADS_PER_BLOCK>>>((BYTE *)d_chunk, (BYTE *)d_chunk, chunkSize);
				}	
				break;
				case ECB_DECRYPT:
				{				
					int offset = 0;
					
					void* ptr = (void*)(size_t)d_chunk;
					void* ptr2 = (void*)(size_t)d_keySchedule_data;
					
					ALIGN_UP(offset, __alignof(ptr));
					cuParamSetv(cuda_aes_decrypt, offset, &ptr, sizeof(ptr));
					offset += sizeof(ptr);
					ALIGN_UP(offset, __alignof(ptr));
					cuParamSetv(cuda_aes_decrypt, offset, &ptr, sizeof(ptr));
					offset += sizeof(ptr);
					ALIGN_UP(offset, __alignof(ptr2));
					cuParamSetv(cuda_aes_decrypt, offset, &ptr2, sizeof(ptr2));
					offset += sizeof(ptr2);
					ALIGN_UP(offset, __alignof(chunkSize));
					cuParamSeti(cuda_aes_decrypt, offset, chunkSize);
					offset += sizeof(chunkSize);

					cuParamSetSize(cuda_aes_decrypt, offset);
					cuFuncSetBlockShape(cuda_aes_decrypt, THREADS_PER_BLOCK, 1, 1);
					cuFuncSetSharedSize(cuda_aes_decrypt, 0);

				 	cuLaunchGrid(cuda_aes_decrypt, BLOCKS_PER_LAUNCH, 1);

					//cuda_aes_decrypt<<<BLOCKS_PER_LAUNCH, THREADS_PER_BLOCK>>>((BYTE *)d_chunk, (BYTE *)d_chunk, chunkSize);
				}
				break;
				default:
					break;
				}
			
				
				checkCudaErrors(cuMemcpyDtoH(h_chunkData, d_chunk, lastChunkSize));
				//gpuErrchk(cudaMemcpy(h_chunkData, d_chunk, lastChunkSize, cudaMemcpyDeviceToHost));
				checkCudaErrors(cuMemFree(d_chunk));
				//gpuErrchk(cudaFree(d_chunk));
				fwrite(h_chunkData, lastChunkSize, 1, fp_out);
				//Increment the counter by the number of blocks that got processed
				if(operation == CTR)
					counter += lastChunkSize / AES_BLOCK_SIZE;
			}
			while(lastChunkSize == chunkSize);
			fclose(fp_in);
		}
	}
	else
	{
		puts("Invalid key file");
	}
}

void pad(char *chunk, int lastBlockRemainder)
{
	//Pad zeros on the last (blocksize - remainder) bytes
	for (int i = 15; i >= lastBlockRemainder; i--)
	{
		chunk[i] = 0x00;
	}
}

//Return 1 if successful, 0 otherwise
CUdeviceptr getKeySchedule(char *keyFilename, Operation operation)
{
	FILE *fp = fopen(keyFilename, "rb");
	//If CTR, read the IV from the first 16 bytes of the file
/*
	if (operation == CTR)
	{
		BYTE iv_file[16];
		if(fread(iv_file, 1, AES_BLOCK_SIZE, fp) < AES_BLOCK_SIZE) return 0;
		gpuErrchk(cudaMemcpyToSymbol(iv, iv_file, AES_BLOCK_SIZE));
	}
*/
	//Allocate the maximum key size of 256 bits
	BYTE *key = (BYTE *)malloc(32);
	//If the key file is longer than 256 bits, the first 256 bits will be used
	int keySize = fread(key, 1, 32, fp) * 8;

	if(keySize != 128 && keySize != 192 && keySize != 256) return 0;

	int Nr, Nk;
	int Nb = 4;
	int keyScheduleSize;
	WORD *keySchedule;
	Nk = keySize / 32;
	Nr = 6 + MAX(Nb, Nk);
	keyScheduleSize = Nb * (Nr + 1);
	keySchedule = (WORD *)malloc(sizeof(WORD) * keyScheduleSize);
	aes_key_setup(key, keySchedule, keySize);

	CUdeviceptr d_keySchedule_data = 0;
	

/*
				gpuErrchk(cuMemAlloc(&d_chunk, lastChunkSize));
				gpuErrchk(cuMemcpyHtoD( d_chunk, h_chunkData, lastChunkSize));
*/

	//cudaMemcpyToSymbol(d_keySchedule, keySchedule, Nr * sizeof(WORD));
	checkCudaErrors(cuMemAlloc(&d_keySchedule_data, keyScheduleSize * sizeof(WORD)));
//	gpuErrchk(cudaMalloc((void **)&d_keySchedule_data, keyScheduleSize*sizeof(WORD)));

	checkCudaErrors(cuMemcpyHtoD(d_keySchedule_data, keySchedule, keyScheduleSize*sizeof(WORD)));
//	gpuErrchk(cudaMemcpy(d_keySchedule_data, keySchedule, keyScheduleSize*sizeof(WORD), cudaMemcpyHostToDevice));

	//gpuErrchk(cudaMemcpyToSymbol(d_keySchedule, &d_keySchedule_data, sizeof(WORD *)));

	return d_keySchedule_data;
}

///Credit for this function goes to Brian Conte, author of the crypto-algorithms project, located at github.com/B-Con/crypto-algorithms
// Performs the action of generating the keys that will be used in every round of
// encryption. "key" is the user-supplied input key, "w" is the output key schedule,
// "keysize" is the length in bits of "key", must be 128, 192, or 256.
void aes_key_setup(const BYTE key[], WORD w[], int keysize)
{
	int Nb=4,Nr,Nk,idx;
	WORD temp,Rcon[]={0x01000000,0x02000000,0x04000000,0x08000000,0x10000000,0x20000000,
	                  0x40000000,0x80000000,0x1b000000,0x36000000,0x6c000000,0xd8000000,
	                  0xab000000,0x4d000000,0x9a000000};

	switch (keysize) {
		case 128: Nr = 10; Nk = 4; break;
		case 192: Nr = 12; Nk = 6; break;
		case 256: Nr = 14; Nk = 8; break;
		default: return;
	}

	for (idx=0; idx < Nk; ++idx) {
		w[idx] = ((key[4 * idx]) << 24) | ((key[4 * idx + 1]) << 16) |
				   ((key[4 * idx + 2]) << 8) | ((key[4 * idx + 3]));
	}

	for (idx = Nk; idx < Nb * (Nr+1); ++idx) {
		temp = w[idx - 1];
		if ((idx % Nk) == 0)
			temp = SubWord(KE_ROTWORD(temp)) ^ Rcon[(idx-1)/Nk];
		else if (Nk > 6 && (idx % Nk) == 4)
			temp = SubWord(temp);
		w[idx] = w[idx-Nk] ^ temp;
	}
}

///Credit for this function goes to Brian Conte, author of the crypto-algorithms project, located at github.com/B-Con/crypto-algorithms
// Substitutes a word using the AES S-Box.
WORD SubWord(WORD word)
{
	unsigned int result;

	result = (int)aes_sbox[(word >> 4) & 0x0000000F][word & 0x0000000F];
	result += (int)aes_sbox[(word >> 12) & 0x0000000F][(word >> 8) & 0x0000000F] << 8;
	result += (int)aes_sbox[(word >> 20) & 0x0000000F][(word >> 16) & 0x0000000F] << 16;
	result += (int)aes_sbox[(word >> 28) & 0x0000000F][(word >> 24) & 0x0000000F] << 24;
	return(result);
}

bool inline
findModulePath(const char *module_file, std::string &module_path, char **argv, std::string &ptx_source)
{
    char *actual_path = sdkFindFilePath(module_file, argv[0]);

    if (actual_path)
    {
        module_path = actual_path;
    }
    else
    {
        printf("> findModulePath file not found: <%s> \n", module_file);
        return false;
    }

    if (module_path.empty())
    {
        printf("> findModulePath file not found: <%s> \n", module_file);
        return false;
    }
    else
    {
        printf("> findModulePath <%s>\n", module_path.c_str());

        if (module_path.rfind(".ptx") != std::string::npos)
        {
            FILE *fp = fopen(module_path.c_str(), "rb");
            fseek(fp, 0, SEEK_END);
            int file_size = ftell(fp);
            char *buf = new char[file_size+1];
            fseek(fp, 0, SEEK_SET);
            fread(buf, sizeof(char), file_size, fp);
            fclose(fp);
            buf[file_size] = '\0';
            ptx_source = buf;
            delete[] buf;
        }

        return true;
    }
}


////////////////////////////////////////////////////////////////////////////////
//! This initializes CUDA, and loads the *.ptx CUDA module containing the
//! kernel function.  After the module is loaded, cuModuleGetFunction
//! retrieves the CUDA function pointer "cuFunction"
////////////////////////////////////////////////////////////////////////////////
static CUresult
initCUDA(int argc, char **argv)
{
    CUfunction cuFunction1 = 0;
    CUfunction cuFunction2 = 0;
    CUfunction cuFunction3 = 0;
    CUresult status;
    int major = 0, minor = 0, devID = 0;
    char deviceName[100];
    std::string module_path, ptx_source;

    cuDevice = findCudaDevice(argc, argv, &devID);

    // get compute capabilities and the devicename
    checkCudaErrors(cuDeviceComputeCapability(&major, &minor, cuDevice));
    checkCudaErrors(cuDeviceGetName(deviceName, 256, cuDevice));
    printf("> GPU Device has SM %d.%d compute capability\n", major, minor);

    status = cuCtxCreate(&cuContext, 0, cuDevice);

    if (CUDA_SUCCESS != status)
    {
        printf("cuCtxCreate(0) returned %d\n-> Bummer\n", status);
        goto Error;
    }

    // first search for the module_path before we try to load the results
    if (!findModulePath(PTX_FILE, module_path, argv, ptx_source))
    {
        if (!findModulePath(CUBIN_FILE, module_path, argv, ptx_source))
        {
            printf("> findModulePath could not find <simpleTexture_kernel> ptx or cubin\n");
            status = CUDA_ERROR_NOT_FOUND;
            goto Error;
        }
    }
    else
    {
        printf("> initCUDA loading module: <%s>\n", module_path.c_str());
    }

    if (module_path.rfind("ptx") != std::string::npos)
    {
        // in this branch we use compilation with parameters
        const unsigned int jitNumOptions = 3;
        CUjit_option *jitOptions = new CUjit_option[jitNumOptions];
        void **jitOptVals = new void *[jitNumOptions];

        // set up size of compilation log buffer
        jitOptions[0] = CU_JIT_INFO_LOG_BUFFER_SIZE_BYTES;
        int jitLogBufferSize = 1024;
        jitOptVals[0] = (void *)(size_t)jitLogBufferSize;

        // set up pointer to the compilation log buffer
        jitOptions[1] = CU_JIT_INFO_LOG_BUFFER;
        char *jitLogBuffer = new char[jitLogBufferSize];
        jitOptVals[1] = jitLogBuffer;

        // set up pointer to set the Maximum # of registers for a particular kernel
        jitOptions[2] = CU_JIT_MAX_REGISTERS;
        int jitRegCount = 32;
        jitOptVals[2] = (void *)(size_t)jitRegCount;

        status = cuModuleLoadDataEx(&cuModule, ptx_source.c_str(), jitNumOptions, jitOptions, (void **)jitOptVals);

        printf("> PTX JIT log:\n%s\n", jitLogBuffer);
    }
    else
    {
        status = cuModuleLoad(&cuModule, module_path.c_str());
    }

    if (CUDA_SUCCESS != status)
    {
	printf("Status not equal CUDA_SUCCESS = %d, bummer\n", status);
        goto Error;
    }

    status = cuModuleGetFunction(&cuFunction1, cuModule, "cuda_aes_encrypt_ctr");
    if(CUDA_SUCCESS != status)
    {
	printf("Unable to find cuda_aes_encrypt_ctr\n");
    }
    status = cuModuleGetFunction(&cuFunction2, cuModule, "cuda_aes_encrypt");
    if(CUDA_SUCCESS != status)
    {
        printf("Unable to find cuda_aes_encrypt\n");
    }
    status = cuModuleGetFunction(&cuFunction3, cuModule, "cuda_aes_decrypt");
    if(CUDA_SUCCESS != status)
    {
        printf("Unable to find cuda_aes_decrypt\n");
    }


    if (CUDA_SUCCESS != status)
    {
	printf("status not equal CUDA_SUCCESS after finding functions\n");
        goto Error;
    }

    cuda_aes_encrypt_ctr = cuFunction1;
    cuda_aes_encrypt = cuFunction2;
    cuda_aes_decrypt = cuFunction3;

    return CUDA_SUCCESS;
Error:
    cuCtxDestroy(cuContext);
    return status;
}
